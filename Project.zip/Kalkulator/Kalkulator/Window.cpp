#include "Window.h"
using namespace System;
using namespace System::Windows::Forms;

[STAThreadAttribute]

int Main(array<System::String ^> ^args) {
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	Kalkulator::Window window;
	Application::Run(%window);
	return 0;
}
