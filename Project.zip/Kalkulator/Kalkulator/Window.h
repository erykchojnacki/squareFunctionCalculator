#pragma once

namespace Kalkulator {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Podsumowanie informacji o Window
	/// </summary>
	public ref class Window : public System::Windows::Forms::Form
	{

		Double a = 0, b = 0, c = 0;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Label^  label1;


	public:
		Window(void)
		{
			InitializeComponent();
			//
			//TODO: W tym miejscu dodaj kod konstruktora
			//
		}

	protected:
		/// <summary>
		/// Wyczy�� wszystkie u�ywane zasoby.
		/// </summary>
		~Window()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  Calculate;
	private: System::Windows::Forms::TextBox^  textBoxA;

	private: System::Windows::Forms::ListBox^  actions;
	private: System::Windows::Forms::TextBox^  textBoxC;


	private: System::Windows::Forms::TextBox^  textBoxB;

	private: System::Windows::Forms::Label^  lblA;

	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	protected:

	protected:

	private:
		/// <summary>
		/// Wymagana zmienna projektanta.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Metoda wymagana do obs�ugi projektanta � nie nale�y modyfikowa�
		/// jej zawarto�ci w edytorze kodu.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Window::typeid));
			this->Calculate = (gcnew System::Windows::Forms::Button());
			this->textBoxA = (gcnew System::Windows::Forms::TextBox());
			this->actions = (gcnew System::Windows::Forms::ListBox());
			this->textBoxC = (gcnew System::Windows::Forms::TextBox());
			this->textBoxB = (gcnew System::Windows::Forms::TextBox());
			this->lblA = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// Calculate
			// 
			this->Calculate->AutoEllipsis = true;
			this->Calculate->BackColor = System::Drawing::Color::DarkOrange;
			this->Calculate->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->Calculate->FlatAppearance->BorderSize = 0;
			this->Calculate->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->Calculate->Font = (gcnew System::Drawing::Font(L"Comfortaa", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->Calculate->ForeColor = System::Drawing::SystemColors::ControlText;
			this->Calculate->Location = System::Drawing::Point(141, 320);
			this->Calculate->Name = L"Calculate";
			this->Calculate->Size = System::Drawing::Size(100, 30);
			this->Calculate->TabIndex = 0;
			this->Calculate->Text = L"Oblicz";
			this->Calculate->UseVisualStyleBackColor = false;
			this->Calculate->Click += gcnew System::EventHandler(this, &Window::Calculate_Click);
			// 
			// textBoxA
			// 
			this->textBoxA->Location = System::Drawing::Point(93, 227);
			this->textBoxA->Name = L"textBoxA";
			this->textBoxA->Size = System::Drawing::Size(44, 20);
			this->textBoxA->TabIndex = 1;
			// 
			// actions
			// 
			this->actions->BackColor = System::Drawing::Color::DarkOrange;
			this->actions->Font = (gcnew System::Drawing::Font(L"Comfortaa", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->actions->ForeColor = System::Drawing::Color::Black;
			this->actions->FormattingEnabled = true;
			this->actions->ImeMode = System::Windows::Forms::ImeMode::NoControl;
			this->actions->ItemHeight = 19;
			this->actions->Items->AddRange(gcnew cli::array< System::Object^  >(6) {
				L"delta", L"posta� iloczynowa", L"posta� kanoniczna",
					L"posta� og�lna", L"x1", L"x2"
			});
			this->actions->Location = System::Drawing::Point(100, 76);
			this->actions->Name = L"actions";
			this->actions->Size = System::Drawing::Size(187, 118);
			this->actions->TabIndex = 2;
			// 
			// textBoxC
			// 
			this->textBoxC->Location = System::Drawing::Point(291, 227);
			this->textBoxC->Name = L"textBoxC";
			this->textBoxC->Size = System::Drawing::Size(44, 20);
			this->textBoxC->TabIndex = 3;
			// 
			// textBoxB
			// 
			this->textBoxB->Location = System::Drawing::Point(187, 227);
			this->textBoxB->Name = L"textBoxB";
			this->textBoxB->Size = System::Drawing::Size(44, 20);
			this->textBoxB->TabIndex = 4;
			// 
			// lblA
			// 
			this->lblA->AutoSize = true;
			this->lblA->BackColor = System::Drawing::Color::DarkOrange;
			this->lblA->Font = (gcnew System::Drawing::Font(L"Comfortaa", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->lblA->Location = System::Drawing::Point(57, 228);
			this->lblA->Name = L"lblA";
			this->lblA->Size = System::Drawing::Size(30, 19);
			this->lblA->TabIndex = 5;
			this->lblA->Text = L"a =";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->BackColor = System::Drawing::Color::DarkOrange;
			this->label2->Font = (gcnew System::Drawing::Font(L"Comfortaa", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(150, 228);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(31, 19);
			this->label2->TabIndex = 6;
			this->label2->Text = L"b =";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->BackColor = System::Drawing::Color::DarkOrange;
			this->label3->Font = (gcnew System::Drawing::Font(L"Comfortaa", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(256, 228);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(29, 19);
			this->label3->TabIndex = 7;
			this->label3->Text = L"c =";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::Color::DarkOrange;
			this->label1->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->label1->Font = (gcnew System::Drawing::Font(L"Comfortaa", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->ForeColor = System::Drawing::Color::Black;
			this->label1->Location = System::Drawing::Point(57, 18);
			this->label1->Name = L"label1";
			this->label1->Padding = System::Windows::Forms::Padding(10);
			this->label1->Size = System::Drawing::Size(294, 43);
			this->label1->TabIndex = 8;
			this->label1->Text = L"Wybierz dzia�anie i podaj dane";
			// 
			// button1
			// 
			this->button1->AutoEllipsis = true;
			this->button1->BackColor = System::Drawing::Color::DarkOrange;
			this->button1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Center;
			this->button1->Enabled = false;
			this->button1->FlatAppearance->BorderSize = 0;
			this->button1->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
			this->button1->Font = (gcnew System::Drawing::Font(L"Comfortaa", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button1->ForeColor = System::Drawing::SystemColors::ControlText;
			this->button1->Location = System::Drawing::Point(32, 209);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(319, 57);
			this->button1->TabIndex = 9;
			this->button1->UseVisualStyleBackColor = false;
			// 
			// Window
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->AutoSize = true;
			this->BackColor = System::Drawing::Color::Black;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(384, 361);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->lblA);
			this->Controls->Add(this->textBoxB);
			this->Controls->Add(this->textBoxC);
			this->Controls->Add(this->actions);
			this->Controls->Add(this->textBoxA);
			this->Controls->Add(this->Calculate);
			this->Controls->Add(this->button1);
			this->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"$this.Icon")));
			this->Name = L"Window";
			this->Text = L"Kalkulator";
			this->TopMost = true;
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
private: System::Void Calculate_Click(System::Object^  sender, System::EventArgs^  e) {
	a = Convert::ToDouble(textBoxA->Text);
	b = Convert::ToDouble(textBoxB->Text);
	c = Convert::ToDouble(textBoxC->Text);
	if (actions->SelectedItem == "delta") {
		MessageBox::Show(Convert::ToString(Delta(a, b, c)), "Wynik", MessageBoxButtons::OK, MessageBoxIcon::Information);
	}
	else if (actions->SelectedItem == "x1") {
		MessageBox::Show(Convert::ToString(X1(a, b, c)), "Wynik", MessageBoxButtons::OK, MessageBoxIcon::Information);
	}
	else if (actions->SelectedItem == "x2") {
		MessageBox::Show(Convert::ToString(X2(a, b, c)), "Wynik", MessageBoxButtons::OK, MessageBoxIcon::Information);
	}
	else if (actions->SelectedItem == "posta� og�lna") {
		MessageBox::Show(Convert::ToString(PostacOgolna(a, b, c)), "Wynik", MessageBoxButtons::OK, MessageBoxIcon::Information);
	}
	else if (actions->SelectedItem == "posta� iloczynowa") {
		MessageBox::Show(Convert::ToString(PostacIloczynowa(a, b, c)), "Wynik", MessageBoxButtons::OK, MessageBoxIcon::Information);
	}
	else if (actions->SelectedItem == "posta� kanoniczna") {
		MessageBox::Show(Convert::ToString(PostacKanoniczna(a, b, c)), "Wynik", MessageBoxButtons::OK, MessageBoxIcon::Information);
	}
}
	System::Double Delta(double f_a, double f_b,double f_c) {
		return f_b * f_b + (4 * f_a * f_c);
	}
	System::Double X1(double f_a, double f_b, double f_c) {
		return -f_b - Math::Sqrt(Delta(f_a,f_b,f_c)) / (2*f_a);
	}
	System::Double X2(double f_a, double f_b, double f_c) {
		return -f_b + Math::Sqrt(Delta(f_a, f_b, f_c)) / (2 * f_a);
	}
	System::Double P(double f_a, double f_b) {
		return -f_b / (2*f_a);
	}
	System::Double Q(double f_a, double f_b, double f_c) {
		return -Delta(f_a,f_b,f_c) / (4* f_a);
	}
	System::String^ PostacOgolna(double f_a, double f_b, double f_c) {
		if (f_a != 0) {
			return "y = " + f_a + "x^2 + " + f_b + "x + " + f_c;
		}
		else { return "Brak postaci og�lnej, poniewa� a = 0"; }
	}
	System::String^ PostacIloczynowa(double f_a, double f_b, double f_c) {
		if (f_a != 0) {
			if (Delta(f_a, f_b, f_c) > 0) {
				return "y = " + f_a + "(x - " + X1(f_a, f_b, f_c) + ")(x - " + X2(f_a, f_b, f_c) + ")";
			}
			else if (Delta(f_a, f_b, f_c) == 0) {
				return "y = " + f_a + "(x-" + -f_b / (2 * f_a) + ")";
			}
			else  {
				return "Brak miejsc zerowych";
			}
		}
		else { return "Brak postaci iloczynowej, poniewa� a = 0"; }
	}
	System::String^ PostacKanoniczna(double f_a, double f_b, double f_c) {
		if (f_a != 0) {
			return "y = " + f_a + "(x - " + P(f_a, f_b) + ")^2 + " + Q(f_a, f_b, f_c);
		}
		else { return "Brak postaci kanonicznej, poniewa� a = 0"; }
	}
};
}
